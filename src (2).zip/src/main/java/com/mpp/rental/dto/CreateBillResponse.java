package com.mpp.rental.dto;

public class CreateBillResponse {
}
