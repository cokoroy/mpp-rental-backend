package com.mpp.rental.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.support.ChannelInterceptor;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        config.enableSimpleBroker("/topic");
        config.setApplicationDestinationPrefixes("/app");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws")
                .setAllowedOriginPatterns("*");
        // NOTE: No .withSockJS() — frontend uses native WebSocket directly
    }

    /**
     * Disable Spring Security's STOMP-level CSRF check (SameOriginCheck).
     *
     * Spring Security adds a CsrfChannelInterceptor to the inbound channel that
     * rejects WebSocket CONNECT frames without a CSRF token — even when HTTP-level
     * CSRF is disabled via csrf.disable() in SecurityConfig.
     *
     * By replacing the inbound channel interceptors with an empty no-op interceptor,
     * we remove the CsrfChannelInterceptor without needing @EnableWebSocketSecurity
     * or spring-security-messaging on the classpath.
     *
     * JWT auth is handled at the HTTP upgrade level via ?token= query param,
     * validated by JwtAuthenticationFilter before the connection is established.
     */
    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {
        registration.interceptors(new ChannelInterceptor() {
            // No-op interceptor — presence of this replaces the default interceptors
            // list, which removes the CsrfChannelInterceptor Spring Security adds.
        });
    }
}