package com.mpp.rental.exception;

public class EventFacilityException extends RuntimeException {
    public EventFacilityException(String message) {
        super(message);
    }
}
